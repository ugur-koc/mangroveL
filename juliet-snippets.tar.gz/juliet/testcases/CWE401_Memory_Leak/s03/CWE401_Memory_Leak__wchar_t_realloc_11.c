#include "std_testcase.h"
#include <wchar.h>
static void goodB2G1()
{
    wchar_t * data;
    data = NULL;
    if(globalReturnsTrue())
    {
        data = (wchar_t *)realloc(data, 100*sizeof(wchar_t));
        wcscpy(data, L"A String");
        printWLine(data);
    }
    if(globalReturnsFalse())
    {
        printLine("Benign, fixed string");
    }
    else
    {
        free(data);
    }
}
void  main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("Calling good()...");
    CWE401_Memory_Leak__wchar_t_realloc_11_good();
    printLine("Finished good()");
     0;
}
