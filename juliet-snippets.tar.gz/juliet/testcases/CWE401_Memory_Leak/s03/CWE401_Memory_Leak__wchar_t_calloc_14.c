#include "std_testcase.h"
#include <wchar.h>
static void goodB2G2()
{
    wchar_t * data;
    data = NULL;
    if(globalFive==5)
    {
        data = (wchar_t *)calloc(100, sizeof(wchar_t));
        wcscpy(data, L"A String");
        printWLine(data);
    }
    if(globalFive==5)
    {
        free(data);
    }
}
void  main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("Calling good()...");
    CWE401_Memory_Leak__wchar_t_calloc_14_good();
    printLine("Finished good()");
     0;
}
