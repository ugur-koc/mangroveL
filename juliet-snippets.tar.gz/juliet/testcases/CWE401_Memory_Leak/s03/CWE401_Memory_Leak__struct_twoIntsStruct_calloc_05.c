#include "std_testcase.h"
static int staticTrue = 1; 
static void goodB2G2()
{
    struct _twoIntsStruct * data;
    data = NULL;
    if(staticTrue)
    {
        data = (struct _twoIntsStruct *)calloc(100, sizeof(struct _twoIntsStruct));
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine((twoIntsStruct *)&data[0]);
    }
    if(staticTrue)
    {
        free(data);
    }
}
void  main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("Calling good()...");
    CWE401_Memory_Leak__struct_twoIntsStruct_calloc_05_good();
    printLine("Finished good()");
     0;
}
