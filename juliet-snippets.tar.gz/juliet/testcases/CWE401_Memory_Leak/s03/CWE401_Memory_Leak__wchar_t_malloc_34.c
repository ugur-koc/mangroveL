#include "std_testcase.h"
#include <wchar.h>
typedef union
{
    wchar_t * unionFirst;
    wchar_t * unionSecond;
} CWE401_Memory_Leak__wchar_t_malloc_34_unionType;
static void goodB2G()
{
    wchar_t * data;
    CWE401_Memory_Leak__wchar_t_malloc_34_unionType myUnion;
    data = NULL;
    data = (wchar_t *)malloc(100*sizeof(wchar_t));
    wcscpy(data, L"A String");
    printWLine(data);
    myUnion.unionFirst = data;
    {
        wchar_t * data = myUnion.unionSecond;
        free(data);
    }
}
void  main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("Calling good()...");
    CWE401_Memory_Leak__wchar_t_malloc_34_good();
    printLine("Finished good()");
     0;
}
