#include "std_testcase.h"
typedef union
{
    twoIntsStruct * unionFirst;
    twoIntsStruct * unionSecond;
} CWE401_Memory_Leak__twoIntsStruct_malloc_34_unionType;
static void goodB2G()
{
    twoIntsStruct * data;
    CWE401_Memory_Leak__twoIntsStruct_malloc_34_unionType myUnion;
    data = NULL;
    data = (twoIntsStruct *)malloc(100*sizeof(twoIntsStruct));
    data[0].intOne = 0;
    data[0].intTwo = 0;
    printStructLine(&data[0]);
    myUnion.unionFirst = data;
    {
        twoIntsStruct * data = myUnion.unionSecond;
        free(data);
    }
}
void  main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("Calling good()...");
    CWE401_Memory_Leak__twoIntsStruct_malloc_34_good();
    printLine("Finished good()");
     0;
}
