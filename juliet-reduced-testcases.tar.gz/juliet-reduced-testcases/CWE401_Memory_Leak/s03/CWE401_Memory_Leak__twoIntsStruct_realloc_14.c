#include "std_testcase.h"
static void goodB2G1()
{
    twoIntsStruct * data;
    data = NULL;
    if(globalFive==5)
    {
        data = (twoIntsStruct *)realloc(data, 100*sizeof(twoIntsStruct));
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
    }
    if(globalFive!=5)
    {
        printLine("Benign, fixed string");
    }
    else
    {
        free(data);
    }
}
void  main(int argc, char * argv[])
{
    srand( (unsigned)time(NULL) );
    printLine("Calling good()...");
    CWE401_Memory_Leak__twoIntsStruct_realloc_14_good();
    printLine("Finished good()");
     0;
}
